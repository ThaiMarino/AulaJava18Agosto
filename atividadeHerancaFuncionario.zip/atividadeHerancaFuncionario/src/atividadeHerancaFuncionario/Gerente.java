package atividadeHerancaFuncionario;

public class Gerente extends Funcionario {

	private String setorGerente;
	
	public Gerente(String nome, double salario, int cargaHoraria) {
		super(nome, salario, cargaHoraria);
		// TODO Auto-generated constructor stub
	}


	public String getSetorGerente() {
		return setorGerente;
	}

	public void setSetorGerente(String setorGerente) {
		this.setorGerente = setorGerente;
	}
	
	public void reajuste() {
		salario = salario*1.1;
	}


	@Override
	public String toString() {
		return "Gerente [setorGerente=" + setorGerente + ", getClass()=" + getClass() + ", hashCode()=" + hashCode() + ", toString()="
				+ super.toString() + "]";
	}
	
	

}
