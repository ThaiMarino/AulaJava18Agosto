package atividadeHerancaFuncionario;

public class Tecnico extends Funcionario {
	
	private String areaTecnico;
	
	public Tecnico(String nome, double salario, int cargaHoraria) {
		super(nome, salario, cargaHoraria);
		// TODO Auto-generated constructor stub
	}


	public String getAreaTecnico() {
		return areaTecnico;
	}

	public void setAreaTecnico(String areaTecnico) {
		this.areaTecnico = areaTecnico;
	}


	@Override
	public String toString() {
		return "Tecnico [areaTecnico=" + areaTecnico + ", getClass()=" + getClass() + ", hashCode()=" + hashCode()
				+ ", toString()=" + super.toString() + "]";
	}

	
}
