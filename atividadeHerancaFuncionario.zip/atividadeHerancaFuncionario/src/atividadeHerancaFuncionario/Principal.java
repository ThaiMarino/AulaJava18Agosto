package atividadeHerancaFuncionario;

import java.util.Scanner;


public class Principal {

	public static void main(String[] args) {
		Funcionario funcionarios[] = new Funcionario[2];
		
		Scanner entrada = new Scanner (System.in);
		
		String nome, setorGerente, areaTecnico;
		int cargo, cargaHoraria;
		int posicao;
		double ajuste;
		double salario;
		
		for(int i = 0; i < funcionarios.length; i++) {
			System.out.println("1. Gerente"
					+ "\n2. Tecnico"
					+ "\nInforme sua profissão");
			cargo=entrada.nextInt();
			
			switch(cargo) {
			case 1:
				System.out.println("Nome: ");
				nome = entrada.next();
				System.out.println("Salario: ");
				salario = entrada.nextDouble();
				System.out.println("Carga Horária: ");
				setorGerente = entrada.next();
				funcionarios[i] = new Gerente(nome, salario, cargaHoraria);
				break;
			case 2:
				System.out.println("Nome: ");
				nome = entrada.next();
				System.out.println("Salario: ");
				salario = entrada.nextDouble();
				System.out.println("Carga Horária: ");
				areaTecnico = entrada.next();
				funcionarios[i] = new Tecnico(nome, salario, cargaHoraria);
				break;
			default:
				System.out.println("Opção inválida!");
				i--;
		}
	}
		
	for(Funcionario funcionario : funcionarios) {
		System.out.println(funcionario.toString());
	}
	
	int operacao = 1;
	
	while(operacao!=0) {
		System.out.println("1. Reajuste"
				+ "\n2. Sair");
		operacao=entrada.nextInt();
		
		switch(operacao) {
		case 1:
			System.out.println("Informe a posição a ser reajustada: ");
			posicao = entrada.nextInt();
			func(cargo)[reajuste]
			posicao = entrada.nextInt();
			contas[posicao].saque(valor); 
			break;
		case 2: 
			System.out.println("Obrigada");
			break;
		default:
			System.out.println("Opção inválida!");
		}
}

	
